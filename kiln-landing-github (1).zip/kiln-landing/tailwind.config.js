/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        slip: '#F2F4F1', // page background, the colour of wet slip
        ink: '#14201F', // text and dark surfaces
        cobalt: { DEFAULT: '#2F4FA8', dark: '#243E87', light: '#E3E9F7' },
        celadon: { DEFAULT: '#BFD6C9', deep: '#7FB09A' },
        ochre: '#E3A72F',
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        body: ['"DM Sans"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      keyframes: {
        rise: {
          '0%': { opacity: '0', transform: 'translateY(14px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
      animation: {
        rise: 'rise 0.7s cubic-bezier(0.2, 0.7, 0.2, 1) both',
      },
    },
  },
  plugins: [],
};
