# Kiln: Landing Page

A modern, fully responsive landing page for **Kiln**, a fictional studio-management product for pottery studios. Built with **React 18**, **Vite** and **Tailwind CSS**.

**Live demo:** `https://<your-username>.github.io/<repo-name>/` *(replace after deploying)*

## Features

- 8 sections: Navbar, Hero, About, Features, How It Works, Testimonials, Pricing, Footer
- Responsive across mobile, tablet and desktop
- Interactive hero: click a piece on the kiln shelf to move it through the firing stages
- Pricing with a monthly / yearly toggle that recalculates prices
- Sticky navbar with scroll-spy highlighting and an animated mobile menu
- Scroll-reveal animations, hover effects, and `prefers-reduced-motion` support
- Accessible markup: semantic landmarks, skip link, ARIA labels, visible focus states
- Content kept in one data file, so copy is easy to change

## Tech stack

| Area | Tool |
| --- | --- |
| UI | React 18 (functional components and hooks) |
| Styling | Tailwind CSS 3 with a custom theme |
| Build | Vite 5 |
| Icons | lucide-react and custom SVGs |
| Deployment | GitHub Actions to GitHub Pages |

## Getting started

```bash
git clone https://github.com/<your-username>/<repo-name>.git
cd <repo-name>
npm install
npm run dev        # http://localhost:5173
```

Other commands:

```bash
npm run build      # production build in dist/
npm run preview    # preview the production build
```

## Project structure

```
src/
  App.jsx                  Page composition
  index.css                Tailwind layers, base styles, reveal and reduced-motion rules
  data/content.js          All copy, plans, steps and links
  hooks/                   useScrolled, useScrollSpy
  lib/cn.js                Class-name helper
  components/
    ui/                    Reusable pieces: Button, Container, Reveal, SectionHeading,
                           Logo, Icon, SocialIcons, KilnLoad
    sections/              Navbar, Hero, About, Features, HowItWorks,
                           Testimonials, Pricing, Footer
```

## Deploying to GitHub Pages

The repo includes a workflow (`.github/workflows/deploy.yml`) that builds and publishes the site on every push to `main`.

1. Push this project to a GitHub repository on the `main` branch.
2. In the repo, go to **Settings > Pages**.
3. Under **Build and deployment > Source**, choose **GitHub Actions**.
4. Open the **Actions** tab and wait for "Deploy to GitHub Pages" to finish.
5. Your site is live at `https://<your-username>.github.io/<repo-name>/`.

## Customising

- Colours and fonts: `tailwind.config.js`
- Text, prices and links: `src/data/content.js`

## License

MIT
