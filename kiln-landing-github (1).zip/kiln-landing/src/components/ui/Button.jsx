import { cn } from '../../lib/cn';

const variants = {
  primary: 'bg-cobalt text-white hover:bg-cobalt-dark',
  secondary: 'border border-ink/25 text-ink hover:border-ink hover:bg-white',
  ink: 'bg-ink text-slip hover:bg-ink/85',
  light: 'bg-white text-ink hover:bg-celadon',
};

const sizes = {
  md: 'px-5 py-2.5 text-sm',
  lg: 'px-6 py-3.5 text-base',
};

/** Renders an <a> when `href` is passed, otherwise a <button>. */
export default function Button({
  variant = 'primary',
  size = 'md',
  href,
  className,
  children,
  ...props
}) {
  const classes = cn(
    'inline-flex items-center justify-center gap-2 rounded-full font-medium transition duration-200 active:scale-[0.98]',
    variants[variant],
    sizes[size],
    className
  );

  if (href) {
    return (
      <a href={href} className={classes} {...props}>
        {children}
      </a>
    );
  }
  return (
    <button type="button" className={classes} {...props}>
      {children}
    </button>
  );
}
