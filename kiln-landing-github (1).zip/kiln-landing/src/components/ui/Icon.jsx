import {
  BarChart3,
  BellRing,
  CalendarCheck,
  CalendarPlus,
  CreditCard,
  Flame,
  PackageCheck,
  Palette,
  Store,
  Users,
} from 'lucide-react';

const ICONS = {
  BarChart3,
  BellRing,
  CalendarCheck,
  CalendarPlus,
  CreditCard,
  Flame,
  PackageCheck,
  Palette,
  Store,
  Users,
};

/** Look up a lucide icon by name so content files stay free of JSX. */
export default function Icon({ name, ...props }) {
  const Component = ICONS[name];
  return Component ? <Component aria-hidden="true" {...props} /> : null;
}
