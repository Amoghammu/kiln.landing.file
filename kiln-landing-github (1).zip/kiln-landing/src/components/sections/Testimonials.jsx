import { Star } from 'lucide-react';
import { TESTIMONIALS } from '../../data/content';
import { cn } from '../../lib/cn';
import Container from '../ui/Container';
import Reveal from '../ui/Reveal';
import SectionHeading from '../ui/SectionHeading';

const initials = (name) =>
  name
    .split(' ')
    .map((n) => n[0])
    .join('');

function Stars() {
  return (
    <div className="flex gap-0.5" role="img" aria-label="5 out of 5 stars">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} size={16} className="fill-ochre text-ochre" aria-hidden="true" />
      ))}
    </div>
  );
}

function Review({ quote, name, role, featured, delay }) {
  return (
    <Reveal
      as="figure"
      delay={delay}
      className={cn(
        'flex flex-col justify-between rounded-2xl p-6 transition duration-300 hover:-translate-y-1 sm:p-8',
        featured ? 'bg-cobalt text-white lg:row-span-2' : 'border border-ink/10 bg-white'
      )}
    >
      <div>
        <Stars />
        <blockquote
          className={cn('mt-5 leading-relaxed', featured ? 'font-display text-2xl font-medium sm:text-3xl' : 'text-lg')}
        >
          {quote}
        </blockquote>
      </div>
      <figcaption className="mt-8 flex items-center gap-3">
        <span
          aria-hidden="true"
          className={cn(
            'flex h-11 w-11 items-center justify-center rounded-full text-sm font-bold',
            featured ? 'bg-white text-cobalt' : 'bg-celadon text-ink'
          )}
        >
          {initials(name)}
        </span>
        <span>
          <span className="block font-semibold">{name}</span>
          <span className={cn('block text-sm', featured ? 'text-white/75' : 'text-ink/60')}>{role}</span>
        </span>
      </figcaption>
    </Reveal>
  );
}

export default function Testimonials() {
  return (
    <section id="reviews" aria-labelledby="reviews-title" className="scroll-mt-20 bg-white/50 py-20 sm:py-28">
      <Container>
        <Reveal>
          <SectionHeading
            id="reviews-title"
            title="Studios that stopped losing pieces"
            description="Hear from the people who run Kiln day to day."
          />
        </Reveal>

        <div className="mt-12 grid gap-5 lg:grid-cols-2">
          {TESTIMONIALS.map((t, i) => (
            <Review key={t.name} {...t} delay={i * 100} />
          ))}
        </div>
      </Container>
    </section>
  );
}
