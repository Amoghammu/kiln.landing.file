import { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';
import { NAV_LINKS } from '../../data/content';
import { useScrolled } from '../../hooks/useScrolled';
import { useScrollSpy } from '../../hooks/useScrollSpy';
import { cn } from '../../lib/cn';
import Button from '../ui/Button';
import Container from '../ui/Container';
import Logo from '../ui/Logo';

const SECTION_IDS = NAV_LINKS.map((l) => l.href.slice(1));

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const scrolled = useScrolled();
  const active = useScrollSpy(SECTION_IDS);

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <header
      id="top"
      className={cn(
        'fixed inset-x-0 top-0 z-50 border-b transition-colors duration-300',
        scrolled || open ? 'border-ink/10 bg-slip/90 backdrop-blur' : 'border-transparent bg-transparent'
      )}
    >
      <Container className="flex h-16 items-center justify-between">
        <Logo />

        <nav aria-label="Primary" className="hidden items-center gap-1 md:flex">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              aria-current={active === link.href.slice(1) ? 'true' : undefined}
              className={cn(
                'rounded-full px-3.5 py-2 text-sm font-medium transition-colors hover:bg-ink/5',
                active === link.href.slice(1) ? 'text-cobalt' : 'text-ink/75'
              )}
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="hidden md:block">
          <Button href="#pricing">Start free trial</Button>
        </div>

        <button
          type="button"
          className="-mr-2 rounded-full p-2 md:hidden"
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
          aria-controls="mobile-menu"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </Container>

      {/* Mobile menu: height animates via grid rows */}
      <div
        id="mobile-menu"
        className={cn(
          'grid transition-[grid-template-rows] duration-300 ease-out md:hidden',
          open ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]'
        )}
      >
        <div className="overflow-hidden">
          <nav aria-label="Mobile" className="flex flex-col gap-1 px-5 pb-6 pt-2 sm:px-8">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                tabIndex={open ? 0 : -1}
                onClick={() => setOpen(false)}
                className="rounded-xl px-3 py-3 text-lg font-medium hover:bg-ink/5"
              >
                {link.label}
              </a>
            ))}
            <Button href="#pricing" size="lg" tabIndex={open ? 0 : -1} onClick={() => setOpen(false)} className="mt-3">
              Start free trial
            </Button>
          </nav>
        </div>
      </div>
    </header>
  );
}
