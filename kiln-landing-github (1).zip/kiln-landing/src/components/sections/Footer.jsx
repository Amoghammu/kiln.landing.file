import { Mail, MapPin, Phone } from 'lucide-react';
import { FOOTER_LINKS } from '../../data/content';
import Container from '../ui/Container';
import Logo from '../ui/Logo';
import { FacebookIcon, InstagramIcon, LinkedinIcon, YoutubeIcon } from '../ui/SocialIcons';

const SOCIALS = [
  { label: 'Instagram', href: '#', Icon: InstagramIcon },
  { label: 'YouTube', href: '#', Icon: YoutubeIcon },
  { label: 'Facebook', href: '#', Icon: FacebookIcon },
  { label: 'LinkedIn', href: '#', Icon: LinkedinIcon },
];

const CONTACT = [
  { Icon: Mail, text: 'hello@kiln.studio', href: 'mailto:hello@kiln.studio' },
  { Icon: Phone, text: '+1 (555) 014-2290', href: 'tel:+15550142290' },
  { Icon: MapPin, text: '24 Foundry Lane, Portland, OR' },
];

export default function Footer() {
  return (
    <footer id="contact" className="scroll-mt-20 bg-ink pb-8 pt-16 text-slip">
      <Container>
        <div className="grid gap-12 lg:grid-cols-[1.4fr_2fr]">
          <div>
            <Logo className="text-slip" />
            <p className="mt-4 max-w-xs leading-relaxed text-slip/70">
              Studio software for the people who make, teach and fire pottery.
            </p>

            <ul className="mt-6 space-y-3 text-[15px]">
              {CONTACT.map(({ Icon, text, href }) => (
                <li key={text} className="flex items-center gap-3 text-slip/80">
                  <Icon size={18} aria-hidden="true" className="shrink-0 text-ochre" />
                  {href ? (
                    <a href={href} className="transition-colors hover:text-white hover:underline">
                      {text}
                    </a>
                  ) : (
                    <span>{text}</span>
                  )}
                </li>
              ))}
            </ul>
          </div>

          <nav aria-label="Footer" className="grid grid-cols-2 gap-8 sm:grid-cols-3">
            {FOOTER_LINKS.map((group) => (
              <div key={group.title}>
                <h3 className="text-base font-semibold">{group.title}</h3>
                <ul className="mt-4 space-y-3 text-[15px]">
                  {group.links.map((link) => (
                    <li key={link.label}>
                      <a href={link.href} className="text-slip/70 transition-colors hover:text-white hover:underline">
                        {link.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </nav>
        </div>

        <div className="mt-14 flex flex-col items-start justify-between gap-6 border-t border-white/15 pt-6 sm:flex-row sm:items-center">
          <p className="text-sm text-slip/60">&copy; {new Date().getFullYear()} Kiln Studio Software. All rights reserved.</p>
          <ul className="flex gap-2">
            {SOCIALS.map(({ label, href, Icon }) => (
              <li key={label}>
                <a
                  href={href}
                  aria-label={label}
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 transition duration-200 hover:-translate-y-0.5 hover:bg-ochre hover:text-ink"
                >
                  <Icon />
                </a>
              </li>
            ))}
          </ul>
        </div>
      </Container>
    </footer>
  );
}
