import { FEATURES } from '../../data/content';
import { cn } from '../../lib/cn';
import Container from '../ui/Container';
import Icon from '../ui/Icon';
import Reveal from '../ui/Reveal';
import SectionHeading from '../ui/SectionHeading';

const TONES = {
  white: { card: 'bg-white border border-ink/10', icon: 'bg-cobalt-light text-cobalt', text: 'text-ink/70' },
  ink: { card: 'bg-ink text-slip', icon: 'bg-white/10 text-ochre', text: 'text-slip/75' },
  celadon: { card: 'bg-celadon', icon: 'bg-white/60 text-ink', text: 'text-ink/75' },
};

function FeatureCard({ icon, title, text, tags, wide, tone = 'white', delay }) {
  const t = TONES[tone];
  return (
    <Reveal
      as="article"
      delay={delay}
      className={cn(
        'group rounded-2xl p-6 transition duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-ink/10 sm:p-7',
        t.card,
        wide && 'lg:col-span-2'
      )}
    >
      <div className={cn('flex h-11 w-11 items-center justify-center rounded-xl transition-transform duration-300 group-hover:rotate-6', t.icon)}>
        <Icon name={icon} size={22} />
      </div>
      <h3 className="mt-5 text-xl font-semibold tracking-tight">{title}</h3>
      <p className={cn('mt-2 max-w-xl leading-relaxed', t.text)}>{text}</p>
      {tags && (
        <ul className="mt-5 flex flex-wrap gap-2">
          {tags.map((tag) => (
            <li key={tag} className="rounded-full bg-white/10 px-3 py-1 text-sm">
              {tag}
            </li>
          ))}
        </ul>
      )}
    </Reveal>
  );
}

export default function Features() {
  return (
    <section id="features" aria-labelledby="features-title" className="scroll-mt-20 bg-white/50 py-20 sm:py-28">
      <Container>
        <Reveal>
          <SectionHeading
            id="features-title"
            title="Everything a studio does, in one place"
            description="From the first booking to the last pickup, Kiln covers the work that happens around the clay."
          />
        </Reveal>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <FeatureCard key={f.title} {...f} delay={(i % 3) * 80} />
          ))}
        </div>
      </Container>
    </section>
  );
}
